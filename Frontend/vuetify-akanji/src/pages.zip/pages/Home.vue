<template>
    <v-container class="fill-height d-flex flex-column justify-center align-center">

        <v-responsive class="text-center" max-width="900" height="600">

            <v-img class="mb-4 mx-auto" height="150" src="@/assets/logo.png" />

            <div>
                <div class="text-body-2 font-weight-light mb-n1">Welcome to</div>
                <h1 class="text-h2 font-weight-bold">Akanji</h1>
            </div>
        </v-responsive>
    </v-container>
</template>

<script setup>
//
</script>