<template>
  <Home />
  
</template>

<script setup>


//
</script>
